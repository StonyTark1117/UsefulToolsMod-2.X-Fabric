package com.stonytark.usefultoolsmod.event;

import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.server.MinecraftServer;

public class ModEvents {

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(ModEvents::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        for (net.minecraft.class_3222 player : server.method_3760().method_14571()) {
            if (player.method_7325()) continue;

            class_1799 main = player.method_6047();
            class_1799 off = player.method_6079();
            handleToolEffects(player, main);
            handleToolEffects(player, off);
        }
    }

    private static void handleToolEffects(class_1657 player, class_1799 held) {
        if (held.method_7960()) return;

        if (held.method_31574(ModItems.OVERPOWER_SWORD)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5904, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5907, 10, 3, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_PICKAXE)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5917, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 10, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_SHOVEL)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5917, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 1, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 5, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_AXE)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5924, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 10, false, false, false));
        }
    }

    private static void applyEffects(class_1657 player, class_1293... effects) {
        for (class_1293 effect : effects) {
            player.method_6092(effect);
        }
    }
}
