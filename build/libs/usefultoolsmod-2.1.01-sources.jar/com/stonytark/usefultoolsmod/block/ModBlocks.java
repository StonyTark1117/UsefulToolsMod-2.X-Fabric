package com.stonytark.usefultoolsmod.block;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

public class ModBlocks {
    public static class_2248 RGOLDBLOCK;
    public static class_2248 HRBLOCK;
    public static class_2248 RGOLDORE;
    public static class_2248 RGOLD_NETHER_ORE;
    public static class_2248 RGOLD_END_ORE;
    public static class_2248 RGOLD_DEEPSLATE_ORE;
    public static class_2248 SEMBLOCK;
    public static class_2248 SOBLOCK;
    public static class_2248 LBLOCK;

    public static void register() {
        RGOLDBLOCK = registerBlock("rgoldblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11533)));
        HRBLOCK = registerBlock("hrblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_22146)));
        RGOLDORE = registerBlock("rgoldore",
                new class_2431(class_6019.method_35017(2, 4),
                        class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11544)));
        RGOLD_NETHER_ORE = registerBlock("rgold_nether_ore",
                new class_2431(class_6019.method_35017(2, 4),
                        class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_22148)));
        RGOLD_END_ORE = registerBlock("rgold_end_ore",
                new class_2431(class_6019.method_35017(2, 4),
                        class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_28700)));
        RGOLD_DEEPSLATE_ORE = registerBlock("rgold_deepslate_ore",
                new class_2431(class_6019.method_35017(2, 4),
                        class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_29033)));
        SEMBLOCK = registerBlock("semblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_27197)));
        SOBLOCK = registerBlock("soblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(5f).method_29292().method_9626(class_2498.field_27197)));
        LBLOCK = registerBlock("lblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11533)));
    }

    private static <T extends class_2248> T registerBlock(String name, T block) {
        class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(UsefultoolsMod.MOD_ID, name), block);
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(UsefultoolsMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
        return block;
    }
}
