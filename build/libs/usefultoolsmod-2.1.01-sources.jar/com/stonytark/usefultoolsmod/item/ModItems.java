package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.item.custom.Dynamite;
import com.stonytark.usefultoolsmod.item.custom.Grenade;
import com.stonytark.usefultoolsmod.item.custom.ModArmorItem;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {
    // Raw materials
    public static class_1792 RGOLD;
    public static class_1792 OBSHARD;
    public static class_1792 SEM;
    public static class_1792 OBINGOT;
    public static class_1792 HRED;
    public static class_1792 RLAPIS;

    // Throwables
    public static class_1792 GRENADE;
    public static class_1792 DYNAMITE;

    // Jemerald tools
    public static class_1792 JEMERALD_SWORD;
    public static class_1792 JEMERALD_PICKAXE;
    public static class_1792 JEMERALD_SHOVEL;
    public static class_1792 JEMERALD_AXE;
    public static class_1792 JEMERALD_HOE;

    // Semerald tools
    public static class_1792 SEMERALD_SWORD;
    public static class_1792 SEMERALD_PICKAXE;
    public static class_1792 SEMERALD_SHOVEL;
    public static class_1792 SEMERALD_AXE;
    public static class_1792 SEMERALD_HOE;

    // Jobsidian tools
    public static class_1792 JOBSIDIAN_SWORD;
    public static class_1792 JOBSIDIAN_PICKAXE;
    public static class_1792 JOBSIDIAN_SHOVEL;
    public static class_1792 JOBSIDIAN_AXE;
    public static class_1792 JOBSIDIAN_HOE;

    // Sobsidian tools
    public static class_1792 SOBSIDIAN_SWORD;
    public static class_1792 SOBSIDIAN_PICKAXE;
    public static class_1792 SOBSIDIAN_SHOVEL;
    public static class_1792 SOBSIDIAN_AXE;
    public static class_1792 SOBSIDIAN_HOE;

    // Overpower tools
    public static class_1792 OVERPOWER_SWORD;
    public static class_1792 OVERPOWER_PICKAXE;
    public static class_1792 OVERPOWER_SHOVEL;
    public static class_1792 OVERPOWER_AXE;

    // Hredstone tools
    public static class_1792 HREDSTONE_SWORD;
    public static class_1792 HREDSTONE_PICKAXE;
    public static class_1792 HREDSTONE_SHOVEL;
    public static class_1792 HREDSTONE_AXE;
    public static class_1792 HREDSTONE_HOE;

    // Rgold tools
    public static class_1792 RGOLD_SWORD;
    public static class_1792 RGOLD_PICKAXE;
    public static class_1792 RGOLD_SHOVEL;
    public static class_1792 RGOLD_AXE;
    public static class_1792 RGOLD_HOE;

    // Rlapis tools
    public static class_1792 RLAPIS_SWORD;
    public static class_1792 RLAPIS_PICKAXE;
    public static class_1792 RLAPIS_SHOVEL;
    public static class_1792 RLAPIS_AXE;
    public static class_1792 RLAPIS_HOE;

    // Armor
    public static class_1792 EMERALD_HELMET;
    public static class_1792 EMERALD_CHESTPLATE;
    public static class_1792 EMERALD_LEGGINGS;
    public static class_1792 EMERALD_BOOTS;

    public static class_1792 HRED_HELMET;
    public static class_1792 HRED_CHESTPLATE;
    public static class_1792 HRED_LEGGINGS;
    public static class_1792 HRED_BOOTS;

    public static class_1792 OBSIDIAN_HELMET;
    public static class_1792 OBSIDIAN_CHESTPLATE;
    public static class_1792 OBSIDIAN_LEGGINGS;
    public static class_1792 OBSIDIAN_BOOTS;

    public static class_1792 RGOLD_HELMET;
    public static class_1792 RGOLD_CHESTPLATE;
    public static class_1792 RGOLD_LEGGINGS;
    public static class_1792 RGOLD_BOOTS;

    public static class_1792 RLAPIS_HELMET;
    public static class_1792 RLAPIS_CHESTPLATE;
    public static class_1792 RLAPIS_LEGGINGS;
    public static class_1792 RLAPIS_BOOTS;

    public static class_1792 OVERPOWER_HELMET;
    public static class_1792 OVERPOWER_CHESTPLATE;
    public static class_1792 OVERPOWER_LEGGINGS;
    public static class_1792 OVERPOWER_BOOTS;

    // Spawn eggs
    public static class_1792 GHOST_SPAWN_EGG;

    public static void register() {
        // Raw materials
        RGOLD = reg("rgold", new class_1792(new class_1792.class_1793().method_7889(64)));
        OBSHARD = reg("obshard", new class_1792(new class_1792.class_1793().method_7889(64)));
        SEM = reg("sem", new class_1792(new class_1792.class_1793().method_7889(64)));
        OBINGOT = reg("obingot", new class_1792(new class_1792.class_1793().method_7889(64)));
        HRED = reg("hred", new class_1792(new class_1792.class_1793().method_7889(64)));
        RLAPIS = reg("rlapis", new class_1792(new class_1792.class_1793().method_7889(64)));

        // Throwables
        GRENADE = reg("grenade", new Grenade(new class_1792.class_1793().method_7889(16)));
        DYNAMITE = reg("dynamite", new Dynamite(new class_1792.class_1793().method_7889(16).method_24359()));

        // Jemerald tools
        JEMERALD_SWORD = reg("jemerald_sword", new class_1829(ModToolTiers.JEMERALD,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.JEMERALD, 3, -2.4f))));
        JEMERALD_PICKAXE = reg("jemerald_pickaxe", new class_1810(ModToolTiers.JEMERALD,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.JEMERALD, 1, -2.8f))));
        JEMERALD_SHOVEL = reg("jemerald_shovel", new class_1821(ModToolTiers.JEMERALD,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.JEMERALD, 1.5f, -3f))));
        JEMERALD_AXE = reg("jemerald_axe", new class_1743(ModToolTiers.JEMERALD,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.JEMERALD, 6, -3.2f))));
        JEMERALD_HOE = reg("jemerald_hoe", new class_1794(ModToolTiers.JEMERALD,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.JEMERALD, 0, -3f))));

        // Semerald tools
        SEMERALD_SWORD = reg("semerald_sword", new class_1829(ModToolTiers.SEMERALD,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.SEMERALD, 3, -2.4f))));
        SEMERALD_PICKAXE = reg("semerald_pickaxe", new class_1810(ModToolTiers.SEMERALD,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.SEMERALD, 1, -2.8f))));
        SEMERALD_SHOVEL = reg("semerald_shovel", new class_1821(ModToolTiers.SEMERALD,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.SEMERALD, 1.5f, -3f))));
        SEMERALD_AXE = reg("semerald_axe", new class_1743(ModToolTiers.SEMERALD,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.SEMERALD, 6, -3.2f))));
        SEMERALD_HOE = reg("semerald_hoe", new class_1794(ModToolTiers.SEMERALD,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.SEMERALD, 0, -3f))));

        // Jobsidian tools
        JOBSIDIAN_SWORD = reg("jobsidian_sword", new class_1829(ModToolTiers.JOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.JOBSIDIAN, 3, -2.4f))));
        JOBSIDIAN_PICKAXE = reg("jobsidian_pickaxe", new class_1810(ModToolTiers.JOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.JOBSIDIAN, 1, -2.8f))));
        JOBSIDIAN_SHOVEL = reg("jobsidian_shovel", new class_1821(ModToolTiers.JOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.JOBSIDIAN, 1.5f, -3f))));
        JOBSIDIAN_AXE = reg("jobsidian_axe", new class_1743(ModToolTiers.JOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.JOBSIDIAN, 6, -3.2f))));
        JOBSIDIAN_HOE = reg("jobsidian_hoe", new class_1794(ModToolTiers.JOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.JOBSIDIAN, 0, -3f))));

        // Sobsidian tools
        SOBSIDIAN_SWORD = reg("sobsidian_sword", new class_1829(ModToolTiers.SOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.SOBSIDIAN, 3, -2.4f))));
        SOBSIDIAN_PICKAXE = reg("sobsidian_pickaxe", new class_1810(ModToolTiers.SOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.SOBSIDIAN, 1, -2.8f))));
        SOBSIDIAN_SHOVEL = reg("sobsidian_shovel", new class_1821(ModToolTiers.SOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.SOBSIDIAN, 1.5f, -3f))));
        SOBSIDIAN_AXE = reg("sobsidian_axe", new class_1743(ModToolTiers.SOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.SOBSIDIAN, 6, -3.2f))));
        SOBSIDIAN_HOE = reg("sobsidian_hoe", new class_1794(ModToolTiers.SOBSIDIAN,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.SOBSIDIAN, 0, -3f))));

        // Overpower tools
        OVERPOWER_SWORD = reg("overpower_sword", new class_1829(ModToolTiers.OVERPOWER,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.OVERPOWER, 3, -2.4f))));
        OVERPOWER_PICKAXE = reg("overpower_pickaxe", new class_1810(ModToolTiers.OVERPOWER,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.OVERPOWER, 1, -2.8f))));
        OVERPOWER_SHOVEL = reg("overpower_shovel", new class_1821(ModToolTiers.OVERPOWER,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.OVERPOWER, 1.5f, -3f))));
        OVERPOWER_AXE = reg("overpower_axe", new class_1743(ModToolTiers.OVERPOWER,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.OVERPOWER, 6, -3.2f))));

        // Hredstone tools
        HREDSTONE_SWORD = reg("hredstone_sword", new class_1829(ModToolTiers.HREDSTONE,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.HREDSTONE, 3, -2.4f))));
        HREDSTONE_PICKAXE = reg("hredstone_pickaxe", new class_1810(ModToolTiers.HREDSTONE,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.HREDSTONE, 1, -2.8f))));
        HREDSTONE_SHOVEL = reg("hredstone_shovel", new class_1821(ModToolTiers.HREDSTONE,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.HREDSTONE, 1.5f, -3f))));
        HREDSTONE_AXE = reg("hredstone_axe", new class_1743(ModToolTiers.HREDSTONE,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.HREDSTONE, 6, -3.2f))));
        HREDSTONE_HOE = reg("hredstone_hoe", new class_1794(ModToolTiers.HREDSTONE,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.HREDSTONE, 0, -3f))));

        // Rgold tools
        RGOLD_SWORD = reg("rgold_sword", new class_1829(ModToolTiers.RGOLD,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.RGOLD, 3, -2.4f))));
        RGOLD_PICKAXE = reg("rgold_pickaxe", new class_1810(ModToolTiers.RGOLD,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.RGOLD, 1, -2.8f))));
        RGOLD_SHOVEL = reg("rgold_shovel", new class_1821(ModToolTiers.RGOLD,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.RGOLD, 1.5f, -3f))));
        RGOLD_AXE = reg("rgold_axe", new class_1743(ModToolTiers.RGOLD,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.RGOLD, 6, -3.2f))));
        RGOLD_HOE = reg("rgold_hoe", new class_1794(ModToolTiers.RGOLD,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.RGOLD, 0, -3f))));

        // Rlapis tools
        RLAPIS_SWORD = reg("rlapis_sword", new class_1829(ModToolTiers.RLAPIS,
                new class_1792.class_1793().method_57348(class_1829.method_57394(ModToolTiers.RLAPIS, 3, -2.4f))));
        RLAPIS_PICKAXE = reg("rlapis_pickaxe", new class_1810(ModToolTiers.RLAPIS,
                new class_1792.class_1793().method_57348(class_1810.method_57346(ModToolTiers.RLAPIS, 1, -2.8f))));
        RLAPIS_SHOVEL = reg("rlapis_shovel", new class_1821(ModToolTiers.RLAPIS,
                new class_1792.class_1793().method_57348(class_1821.method_57346(ModToolTiers.RLAPIS, 1.5f, -3f))));
        RLAPIS_AXE = reg("rlapis_axe", new class_1743(ModToolTiers.RLAPIS,
                new class_1792.class_1793().method_57348(class_1743.method_57346(ModToolTiers.RLAPIS, 6, -3.2f))));
        RLAPIS_HOE = reg("rlapis_hoe", new class_1794(ModToolTiers.RLAPIS,
                new class_1792.class_1793().method_57348(class_1794.method_57346(ModToolTiers.RLAPIS, 0, -3f))));

        // Armor
        EMERALD_HELMET = reg("emerald_helmet", new class_1738(ModArmorMaterials.EMERALD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(33))));
        EMERALD_CHESTPLATE = reg("emerald_chestplate", new class_1738(ModArmorMaterials.EMERALD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(33))));
        EMERALD_LEGGINGS = reg("emerald_leggings", new class_1738(ModArmorMaterials.EMERALD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(33))));
        EMERALD_BOOTS = reg("emerald_boots", new class_1738(ModArmorMaterials.EMERALD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(33))));

        HRED_HELMET = reg("hred_helmet", new class_1738(ModArmorMaterials.HRED_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(20))));
        HRED_CHESTPLATE = reg("hred_chestplate", new class_1738(ModArmorMaterials.HRED_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(20))));
        HRED_LEGGINGS = reg("hred_leggings", new class_1738(ModArmorMaterials.HRED_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(20))));
        HRED_BOOTS = reg("hred_boots", new class_1738(ModArmorMaterials.HRED_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(20))));

        OBSIDIAN_HELMET = reg("obsidian_helmet", new class_1738(ModArmorMaterials.OBSIDIAN_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(45))));
        OBSIDIAN_CHESTPLATE = reg("obsidian_chestplate", new class_1738(ModArmorMaterials.OBSIDIAN_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(45))));
        OBSIDIAN_LEGGINGS = reg("obsidian_leggings", new class_1738(ModArmorMaterials.OBSIDIAN_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(45))));
        OBSIDIAN_BOOTS = reg("obsidian_boots", new class_1738(ModArmorMaterials.OBSIDIAN_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(45))));

        RGOLD_HELMET = reg("rgold_helmet", new class_1738(ModArmorMaterials.RGOLD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(18))));
        RGOLD_CHESTPLATE = reg("rgold_chestplate", new class_1738(ModArmorMaterials.RGOLD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(18))));
        RGOLD_LEGGINGS = reg("rgold_leggings", new class_1738(ModArmorMaterials.RGOLD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(18))));
        RGOLD_BOOTS = reg("rgold_boots", new class_1738(ModArmorMaterials.RGOLD_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(18))));

        RLAPIS_HELMET = reg("rlapis_helmet", new class_1738(ModArmorMaterials.RLAPIS_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(17))));
        RLAPIS_CHESTPLATE = reg("rlapis_chestplate", new class_1738(ModArmorMaterials.RLAPIS_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(17))));
        RLAPIS_LEGGINGS = reg("rlapis_leggings", new class_1738(ModArmorMaterials.RLAPIS_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(17))));
        RLAPIS_BOOTS = reg("rlapis_boots", new class_1738(ModArmorMaterials.RLAPIS_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(17))));

        OVERPOWER_HELMET = reg("overpower_helmet", new ModArmorItem(ModArmorMaterials.OVERPOWER_ARMOR_MATERIAL,
                class_1738.class_8051.field_41934, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(100))));
        OVERPOWER_CHESTPLATE = reg("overpower_chestplate", new class_1738(ModArmorMaterials.OVERPOWER_ARMOR_MATERIAL,
                class_1738.class_8051.field_41935, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(100))));
        OVERPOWER_LEGGINGS = reg("overpower_leggings", new class_1738(ModArmorMaterials.OVERPOWER_ARMOR_MATERIAL,
                class_1738.class_8051.field_41936, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(100))));
        OVERPOWER_BOOTS = reg("overpower_boots", new class_1738(ModArmorMaterials.OVERPOWER_ARMOR_MATERIAL,
                class_1738.class_8051.field_41937, new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(100))));

        // Spawn eggs (must be registered AFTER entities)
        GHOST_SPAWN_EGG = reg("ghost_spawn_egg",
                new class_1826(ModEntities.GHOST, 0xFFFFFF, 0x999999, new class_1792.class_1793()));
    }

    private static <T extends class_1792> T reg(String name, T item) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(UsefultoolsMod.MOD_ID, name), item);
        return item;
    }
}
