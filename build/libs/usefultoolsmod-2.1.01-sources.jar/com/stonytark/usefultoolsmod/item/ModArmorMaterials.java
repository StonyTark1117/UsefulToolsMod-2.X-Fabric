package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModArmorMaterials {
    public static class_6880<class_1741> RGOLD_ARMOR_MATERIAL;
    public static class_6880<class_1741> OBSIDIAN_ARMOR_MATERIAL;
    public static class_6880<class_1741> EMERALD_ARMOR_MATERIAL;
    public static class_6880<class_1741> OVERPOWER_ARMOR_MATERIAL;
    public static class_6880<class_1741> HRED_ARMOR_MATERIAL;
    public static class_6880<class_1741> RLAPIS_ARMOR_MATERIAL;

    public static void register() {
        RGOLD_ARMOR_MATERIAL = register("rgold", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 3);
            m.put(class_1738.class_8051.field_41936, 5);
            m.put(class_1738.class_8051.field_41935, 5);
            m.put(class_1738.class_8051.field_41934, 3);
            m.put(class_1738.class_8051.field_48838, 9);
        }), 25, 2f, 0.1f, () -> ModItems.RGOLD);

        OBSIDIAN_ARMOR_MATERIAL = register("obsidian", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 6);
            m.put(class_1738.class_8051.field_41936, 7);
            m.put(class_1738.class_8051.field_41935, 9);
            m.put(class_1738.class_8051.field_41934, 6);
            m.put(class_1738.class_8051.field_48838, 10);
        }), 10, 4f, 0.4f, () -> ModItems.OBINGOT);

        EMERALD_ARMOR_MATERIAL = register("emerald", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 4);
            m.put(class_1738.class_8051.field_41936, 6);
            m.put(class_1738.class_8051.field_41935, 8);
            m.put(class_1738.class_8051.field_41934, 4);
            m.put(class_1738.class_8051.field_48838, 9);
        }), 30, 2f, 0.15f, () -> ModItems.SEM);

        OVERPOWER_ARMOR_MATERIAL = register("overpower", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 15);
            m.put(class_1738.class_8051.field_41936, 15);
            m.put(class_1738.class_8051.field_41935, 15);
            m.put(class_1738.class_8051.field_41934, 15);
            m.put(class_1738.class_8051.field_48838, 15);
        }), 50, 8f, 1f, () -> ModItems.OBINGOT);

        HRED_ARMOR_MATERIAL = register("hred", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 2);
            m.put(class_1738.class_8051.field_41936, 4);
            m.put(class_1738.class_8051.field_41935, 4);
            m.put(class_1738.class_8051.field_41934, 3);
            m.put(class_1738.class_8051.field_48838, 6);
        }), 23, 1.1f, 0.08f, () -> ModItems.HRED);

        RLAPIS_ARMOR_MATERIAL = register("rlapis", class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 3);
            m.put(class_1738.class_8051.field_41936, 6);
            m.put(class_1738.class_8051.field_41935, 4);
            m.put(class_1738.class_8051.field_41934, 4);
            m.put(class_1738.class_8051.field_48838, 8);
        }), 32, 1.6f, 0.15f, () -> ModItems.RLAPIS);
    }

    private static class_6880<class_1741> register(String name, EnumMap<class_1738.class_8051, Integer> protection,
                                                          int enchantability, float toughness, float knockbackResistance,
                                                          Supplier<class_1792> repairItem) {
        class_2960 id = class_2960.method_60655(UsefultoolsMod.MOD_ID, name);
        class_6880<class_3414> equipSound = class_3417.field_14883;
        List<class_1741.class_9196> layers = List.of(new class_1741.class_9196(id));
        class_1741 material = new class_1741(protection, enchantability, equipSound,
                () -> class_1856.method_8091(repairItem.get()), layers, toughness, knockbackResistance);
        return class_2378.method_47985(class_7923.field_48976, id, material);
    }
}
