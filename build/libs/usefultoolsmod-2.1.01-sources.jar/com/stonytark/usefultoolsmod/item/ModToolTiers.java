package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.util.ModTags;
import java.util.function.Supplier;
import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_6862;

public class ModToolTiers {

    public static final class_1832 JEMERALD = create(ModTags.Blocks.INCORRECT_JEM_TOOL,
            1361, 4.5f, 6, 22, () -> class_1856.method_8091(class_1802.field_8687));

    public static final class_1832 SEMERALD = create(ModTags.Blocks.INCORRECT_SEM_TOOL,
            1561, 3.2f, 7, 30, () -> class_1856.method_8091(ModItems.SEM));

    public static final class_1832 JOBSIDIAN = create(ModTags.Blocks.INCORRECT_JOB_TOOL,
            1650, 6f, 9, 15, () -> class_1856.method_8091(ModItems.OBSHARD));

    public static final class_1832 SOBSIDIAN = create(ModTags.Blocks.INCORRECT_SOB_TOOL,
            2031, 5f, 10, 18, () -> class_1856.method_8091(ModItems.OBINGOT));

    public static final class_1832 OVERPOWER = create(ModTags.Blocks.INCORRECT_OP_TOOL,
            9999, 30f, 25, 35, () -> class_1856.method_8091(ModBlocks.SOBLOCK.method_8389()));

    public static final class_1832 HREDSTONE = create(ModTags.Blocks.INCORRECT_HRED_TOOL,
            600, 3f, 8, 20, () -> class_1856.method_8091(ModItems.HRED));

    public static final class_1832 RGOLD = create(ModTags.Blocks.INCORRECT_RGOLD_TOOL,
            1200, 3.5f, 8, 16, () -> class_1856.method_8091(ModItems.RGOLD));

    public static final class_1832 RLAPIS = create(ModTags.Blocks.INCORRECT_RLAPIS_TOOL,
            1100, 3.2f, 9, 32, () -> class_1856.method_8091(ModItems.RGOLD));

    private static class_1832 create(class_6862<class_2248> inverseTag, int durability, float miningSpeed,
                                       float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) {
        return new class_1832() {
            @Override
            public int method_8025() { return durability; }
            @Override
            public float method_8027() { return miningSpeed; }
            @Override
            public float method_8028() { return attackDamage; }
            @Override
            public class_6862<class_2248> method_58419() { return inverseTag; }
            @Override
            public int method_8026() { return enchantability; }
            @Override
            public class_1856 method_8023() { return repairIngredient.get(); }
        };
    }
}
