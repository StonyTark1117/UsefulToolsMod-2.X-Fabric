package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModCreativeModeTabs {

    public static void register() {
        // Custom creative tab with all mod items
        class_2378.method_10230(class_7923.field_44687,
                class_2960.method_60655(UsefultoolsMod.MOD_ID, "usefultools"),
                FabricItemGroup.builder()
                        .method_47321(class_2561.method_43471("itemGroup.usefultoolsmod.usefultools"))
                        .method_47320(() -> new class_1799(ModItems.RGOLD))
                        .method_47317((context, entries) -> {
                            // Materials
                            entries.method_45421(ModItems.RGOLD);
                            entries.method_45421(ModItems.OBSHARD);
                            entries.method_45421(ModItems.SEM);
                            entries.method_45421(ModItems.OBINGOT);
                            entries.method_45421(ModItems.HRED);
                            entries.method_45421(ModItems.RLAPIS);
                            // Throwables
                            entries.method_45421(ModItems.GRENADE);
                            entries.method_45421(ModItems.DYNAMITE);
                            // Blocks
                            entries.method_45421(ModBlocks.RGOLDBLOCK);
                            entries.method_45421(ModBlocks.HRBLOCK);
                            entries.method_45421(ModBlocks.SEMBLOCK);
                            entries.method_45421(ModBlocks.SOBLOCK);
                            entries.method_45421(ModBlocks.LBLOCK);
                            entries.method_45421(ModBlocks.RGOLDORE);
                            entries.method_45421(ModBlocks.RGOLD_DEEPSLATE_ORE);
                            entries.method_45421(ModBlocks.RGOLD_END_ORE);
                            entries.method_45421(ModBlocks.RGOLD_NETHER_ORE);
                            // Tools
                            entries.method_45421(ModItems.JEMERALD_SWORD);
                            entries.method_45421(ModItems.JEMERALD_PICKAXE);
                            entries.method_45421(ModItems.JEMERALD_SHOVEL);
                            entries.method_45421(ModItems.JEMERALD_AXE);
                            entries.method_45421(ModItems.JEMERALD_HOE);
                            entries.method_45421(ModItems.SEMERALD_SWORD);
                            entries.method_45421(ModItems.SEMERALD_PICKAXE);
                            entries.method_45421(ModItems.SEMERALD_SHOVEL);
                            entries.method_45421(ModItems.SEMERALD_AXE);
                            entries.method_45421(ModItems.SEMERALD_HOE);
                            entries.method_45421(ModItems.JOBSIDIAN_SWORD);
                            entries.method_45421(ModItems.JOBSIDIAN_PICKAXE);
                            entries.method_45421(ModItems.JOBSIDIAN_SHOVEL);
                            entries.method_45421(ModItems.JOBSIDIAN_AXE);
                            entries.method_45421(ModItems.JOBSIDIAN_HOE);
                            entries.method_45421(ModItems.SOBSIDIAN_SWORD);
                            entries.method_45421(ModItems.SOBSIDIAN_PICKAXE);
                            entries.method_45421(ModItems.SOBSIDIAN_SHOVEL);
                            entries.method_45421(ModItems.SOBSIDIAN_AXE);
                            entries.method_45421(ModItems.SOBSIDIAN_HOE);
                            entries.method_45421(ModItems.OVERPOWER_SWORD);
                            entries.method_45421(ModItems.OVERPOWER_PICKAXE);
                            entries.method_45421(ModItems.OVERPOWER_SHOVEL);
                            entries.method_45421(ModItems.OVERPOWER_AXE);
                            entries.method_45421(ModItems.HREDSTONE_SWORD);
                            entries.method_45421(ModItems.HREDSTONE_PICKAXE);
                            entries.method_45421(ModItems.HREDSTONE_SHOVEL);
                            entries.method_45421(ModItems.HREDSTONE_AXE);
                            entries.method_45421(ModItems.HREDSTONE_HOE);
                            entries.method_45421(ModItems.RGOLD_SWORD);
                            entries.method_45421(ModItems.RGOLD_PICKAXE);
                            entries.method_45421(ModItems.RGOLD_SHOVEL);
                            entries.method_45421(ModItems.RGOLD_AXE);
                            entries.method_45421(ModItems.RGOLD_HOE);
                            entries.method_45421(ModItems.RLAPIS_SWORD);
                            entries.method_45421(ModItems.RLAPIS_PICKAXE);
                            entries.method_45421(ModItems.RLAPIS_SHOVEL);
                            entries.method_45421(ModItems.RLAPIS_AXE);
                            entries.method_45421(ModItems.RLAPIS_HOE);
                            // Armor
                            entries.method_45421(ModItems.EMERALD_HELMET);
                            entries.method_45421(ModItems.EMERALD_CHESTPLATE);
                            entries.method_45421(ModItems.EMERALD_LEGGINGS);
                            entries.method_45421(ModItems.EMERALD_BOOTS);
                            entries.method_45421(ModItems.HRED_HELMET);
                            entries.method_45421(ModItems.HRED_CHESTPLATE);
                            entries.method_45421(ModItems.HRED_LEGGINGS);
                            entries.method_45421(ModItems.HRED_BOOTS);
                            entries.method_45421(ModItems.OBSIDIAN_HELMET);
                            entries.method_45421(ModItems.OBSIDIAN_CHESTPLATE);
                            entries.method_45421(ModItems.OBSIDIAN_LEGGINGS);
                            entries.method_45421(ModItems.OBSIDIAN_BOOTS);
                            entries.method_45421(ModItems.RGOLD_HELMET);
                            entries.method_45421(ModItems.RGOLD_CHESTPLATE);
                            entries.method_45421(ModItems.RGOLD_LEGGINGS);
                            entries.method_45421(ModItems.RGOLD_BOOTS);
                            entries.method_45421(ModItems.RLAPIS_HELMET);
                            entries.method_45421(ModItems.RLAPIS_CHESTPLATE);
                            entries.method_45421(ModItems.RLAPIS_LEGGINGS);
                            entries.method_45421(ModItems.RLAPIS_BOOTS);
                            entries.method_45421(ModItems.OVERPOWER_HELMET);
                            entries.method_45421(ModItems.OVERPOWER_CHESTPLATE);
                            entries.method_45421(ModItems.OVERPOWER_LEGGINGS);
                            entries.method_45421(ModItems.OVERPOWER_BOOTS);
                            // Spawn eggs
                            entries.method_45421(ModItems.GHOST_SPAWN_EGG);
                        })
                        .method_47324());

        // Also add to vanilla tabs
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> {
            content.method_45421(ModItems.RGOLD);
            content.method_45421(ModItems.OBSHARD);
            content.method_45421(ModItems.SEM);
            content.method_45421(ModItems.OBINGOT);
            content.method_45421(ModItems.HRED);
            content.method_45421(ModItems.RLAPIS);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> {
            content.method_45421(ModItems.GRENADE);
            content.method_45421(ModItems.DYNAMITE);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(content -> {
            content.method_45421(ModBlocks.RGOLDBLOCK);
            content.method_45421(ModBlocks.HRBLOCK);
            content.method_45421(ModBlocks.SEMBLOCK);
            content.method_45421(ModBlocks.SOBLOCK);
            content.method_45421(ModBlocks.LBLOCK);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(content -> {
            content.method_45421(ModBlocks.RGOLDORE);
            content.method_45421(ModBlocks.RGOLD_DEEPSLATE_ORE);
            content.method_45421(ModBlocks.RGOLD_END_ORE);
            content.method_45421(ModBlocks.RGOLD_NETHER_ORE);
        });
    }
}
