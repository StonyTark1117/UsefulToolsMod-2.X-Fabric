package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class Dynamite extends class_1792 {
    private static final float EXPLOSION_RADIUS = 20.0F;

    public Dynamite(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_15079, class_3419.field_15248,
                0.7F, 0.8F + world.field_9229.method_43057() * 0.2F);

        if (world.field_9236) {
            for (int i = 0; i < 150; i++) {
                double offsetX = (world.field_9229.method_43058() - 0.5) * 2.0;
                double offsetY = world.field_9229.method_43058() * 1.5;
                double offsetZ = (world.field_9229.method_43058() - 0.5) * 2.0;
                world.method_8406(
                        class_2398.field_11237,
                        player.method_23317() + offsetX,
                        player.method_23318() + 1.0 + offsetY,
                        player.method_23321() + offsetZ,
                        0.0, 0.0, 0.0
                );
            }
        }

        if (!world.field_9236) {
            world.method_8437(null, player.method_23317(), player.method_23318(), player.method_23321(),
                    EXPLOSION_RADIUS, class_1937.class_7867.field_40891);
        }

        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1271.method_29237(stack, world.method_8608());
    }
}
