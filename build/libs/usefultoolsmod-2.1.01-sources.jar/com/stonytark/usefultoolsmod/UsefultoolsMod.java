package com.stonytark.usefultoolsmod;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import com.stonytark.usefultoolsmod.event.ModEvents;
import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import com.stonytark.usefultoolsmod.item.ModCreativeModeTabs;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1429;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9169;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UsefultoolsMod implements ModInitializer {
    public static final String MOD_ID = "usefultoolsmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Useful Tools Mod (Fabric)");

        // Register in correct dependency order
        ModEntities.register();
        ModArmorMaterials.register();
        ModBlocks.register();
        ModItems.register();
        ModCreativeModeTabs.register();

        // Register entity attributes
        FabricDefaultAttributeRegistry.register(ModEntities.GHOST, GhostEntity.createAttributes());

        // Register spawn placements
        class_1317.method_20637(ModEntities.GHOST,
                class_9169.field_48745,
                class_2902.class_2903.field_13203,
                class_1429::method_20663);

        // Register events
        ModEvents.register();

        // Register worldgen (biome modifications)
        registerWorldgen();
    }

    private void registerWorldgen() {
        // Overworld rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        class_2960.method_60655(MOD_ID, "rgold_ore_placed")));

        // Nether rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        class_2960.method_60655(MOD_ID, "nether_rgold_ore_placed")));

        // End rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        class_2960.method_60655(MOD_ID, "end_rgold_ore_placed")));

        // Ghost spawn (overworld)
        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_6302,
                ModEntities.GHOST,
                5, 1, 3);
    }
}
