package com.stonytark.usefultoolsmod.entity.client;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class GhostModel<T extends GhostEntity> extends class_5597<T> {
    public static final class_5601 LAYER_LOCATION =
            new class_5601(class_2960.method_60655(UsefultoolsMod.MOD_ID, "ghost"), "main");

    private final class_630 body;
    private final class_630 head;

    public GhostModel(class_630 root) {
        this.body = root.method_32086("body");
        this.head = body.method_32086("head");
    }

    public static class_5607 createBodyLayer() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();

        class_5610 body = partdefinition.method_32117("body",
                class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));

        body.method_32117("head",
                class_5606.method_32108().method_32101(0, 0).method_32098(-5.0F, -23.0F, -13.0F, 10.0F, 10.0F, 10.0F, new class_5605(2.0F)),
                class_5603.field_27701);

        class_5610 tail = body.method_32117("tail",
                class_5606.method_32108(), class_5603.field_27701);

        tail.method_32117("tail_start",
                class_5606.method_32108().method_32101(0, 20).method_32098(-1.0F, -18.0F, 3.0F, 4.0F, 4.0F, 1.0F, new class_5605(2.0F)),
                class_5603.field_27701);

        tail.method_32117("tail_second",
                class_5606.method_32108().method_32101(18, 20).method_32098(0.0F, -16.0F, 9.0F, 2.0F, 2.0F, 1.0F, new class_5605(1.0F)),
                class_5603.field_27701);

        tail.method_32117("tail_third",
                class_5606.method_32108().method_32101(18, 23).method_32098(1.0F, -18.0F, 13.0F, 1.0F, 1.0F, 1.0F, new class_5605(1.0F)),
                class_5603.field_27701);

        tail.method_32117("tail_end",
                class_5606.method_32108().method_32101(10, 20).method_32098(-1.0F, -18.0F, 16.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)),
                class_5603.field_27701);

        return class_5607.method_32110(meshdefinition, 64, 64);
    }

    @Override
    public void setAngles(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.method_32008().method_32088().forEach(class_630::method_41923);
        this.applyHeadRotation(headYaw, headPitch);

        this.method_43782(entity.idleAnimationState, GhostAnimations.ANIM_GHOST_IDLE, animationProgress, 1f);
    }

    private void applyHeadRotation(float headYaw, float headPitch) {
        headYaw = class_3532.method_15363(headYaw, -30.0F, 30.0F);
        headPitch = class_3532.method_15363(headPitch, -25.0F, 45.0F);
        this.head.field_3675 = headYaw * ((float) Math.PI / 180F);
        this.head.field_3654 = headPitch * ((float) Math.PI / 180F);
    }

    @Override
    public void method_2828(class_4587 matrices, class_4588 vertices, int light, int overlay, int color) {
        body.method_22699(matrices, vertices, light, overlay, color);
    }

    @Override
    public class_630 method_32008() {
        return body;
    }
}
