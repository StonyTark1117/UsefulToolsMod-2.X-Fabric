package com.stonytark.usefultoolsmod.entity.client;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

public class GhostAnimations {

    public static final class_7184 ANIM_GHOST_IDLE = class_7184.class_7185.method_41818(5.5f).method_41817()
            .method_41820("head",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(-1f, -2f, 1f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(1.75f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(3.75f, class_7187.method_41823(1f, 2f, -1f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(5.5f, class_7187.method_41823(-1f, -2f, 1f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_end",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(1.75f, class_7187.method_41823(-2f, -2f, -1f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(3.75f, class_7187.method_41823(2f, 2f, 1f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(5.5f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_start",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(1.75f, class_7187.method_41823(0f, 8f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(3.75f, class_7187.method_41823(0f, -4f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(5.5f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_second",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(1.75f, class_7187.method_41823(0f, -4f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(3.75f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(5.5f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_third",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(1.75f, class_7187.method_41823(0f, 3f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(3.75f, class_7187.method_41823(0f, -3f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(5.5f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41821();

    public static final class_7184 ANIM_GHOST_WALKING = class_7184.class_7185.method_41818(12f).method_41817()
            .method_41820("head",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(4f, class_7187.method_41823(0f, 14f, -7f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(8f, class_7187.method_41823(0f, 0f, -14f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(12f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_end",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(4f, class_7187.method_41823(-1f, 0.5f, -10f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(8f, class_7187.method_41823(-2f, -1f, -20f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(12f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_start",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(4f, class_7187.method_41823(0f, 9f, -8f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(8f, class_7187.method_41823(0f, 0f, -16f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(12f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_second",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(4f, class_7187.method_41823(0f, 6f, -9f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(8f, class_7187.method_41823(0f, 0f, -18f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(12f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41820("tail_third",
                    new class_7179(class_7179.class_7183.field_37886,
                            new class_7186(0f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(4f, class_7187.method_41823(0f, 2f, -9.5f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(8f, class_7187.method_41823(0f, -2f, -19f),
                                    class_7179.class_7181.field_37884),
                            new class_7186(12f, class_7187.method_41823(0f, 0f, 0f),
                                    class_7179.class_7181.field_37884)))
            .method_41821();
}
