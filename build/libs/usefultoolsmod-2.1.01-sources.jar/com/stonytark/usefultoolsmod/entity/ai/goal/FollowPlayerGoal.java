package com.stonytark.usefultoolsmod.entity.ai.goal;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class FollowPlayerGoal extends class_1352 {
    private final class_1308 mob;
    private class_1657 targetPlayer;
    private final double speedModifier;
    private final double followRange;
    private final double stopDistance;

    public FollowPlayerGoal(class_1308 mob, double speedModifier, double followRange, double stopDistance) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.followRange = followRange;
        this.stopDistance = stopDistance;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        List<class_1657> players = mob.method_37908().method_8390(class_1657.class,
                mob.method_5829().method_1014(followRange),
                player -> player.method_5805() && !player.method_7325());

        double closestDistance = Double.MAX_VALUE;
        class_1657 closestPlayer = null;

        for (class_1657 player : players) {
            double dist = mob.method_5858(player);
            if (dist < closestDistance && mob.method_6057(player)) {
                closestDistance = dist;
                closestPlayer = player;
            }
        }

        if (closestPlayer != null) {
            this.targetPlayer = closestPlayer;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        return targetPlayer != null
                && targetPlayer.method_5805()
                && mob.method_5858(targetPlayer) > stopDistance * stopDistance
                && mob.method_6057(targetPlayer);
    }

    @Override
    public void method_6270() {
        targetPlayer = null;
        mob.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (targetPlayer == null) return;
        class_243 targetPos = targetPlayer.method_19538();
        mob.method_5988().method_6226(targetPlayer, 30.0F, 30.0F);
        mob.method_5942().method_6337(targetPos.field_1352, targetPos.field_1351 + 1.0D, targetPos.field_1350, speedModifier);
    }
}
