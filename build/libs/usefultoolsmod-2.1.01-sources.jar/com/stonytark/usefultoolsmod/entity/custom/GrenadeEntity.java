package com.stonytark.usefultoolsmod.entity.custom;

import com.stonytark.usefultoolsmod.item.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_3857;

public class GrenadeEntity extends class_3857 {
    private static final float EXPLOSION_RADIUS = 10.0F;

    public GrenadeEntity(class_1299<? extends GrenadeEntity> type, class_1937 world) {
        super(type, world);
    }

    public GrenadeEntity(class_1299<? extends GrenadeEntity> type, class_1937 world, class_1309 thrower) {
        super(type, thrower, world);
    }

    @Override
    protected void method_7488(class_239 hitResult) {
        super.method_7488(hitResult);
        if (!this.method_37908().field_9236) {
            this.method_37908().method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(),
                    EXPLOSION_RADIUS, class_1937.class_7867.field_40891);
            this.method_31472();
        } else {
            for (int i = 0; i < 10; i++) {
                this.method_37908().method_8406(class_2398.field_11251,
                        this.method_23317(), this.method_23318(), this.method_23321(), 0.0D, 0.1D, 0.0D);
            }
        }
    }

    @Override
    protected class_1792 method_16942() {
        return ModItems.GRENADE;
    }
}
