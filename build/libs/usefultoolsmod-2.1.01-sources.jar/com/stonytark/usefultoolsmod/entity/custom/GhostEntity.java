package com.stonytark.usefultoolsmod.entity.custom;

import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.ai.goal.FollowPlayerGoal;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1331;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1379;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7094;
import net.minecraft.class_8103;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class GhostEntity extends class_1429 {
    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;
    private int lifetime = 0;
    private static final int MAX_LIFETIME = 5 * 60 * 20;

    public GhostEntity(class_1299<? extends class_1429> type, class_1937 world) {
        super(type, world);
        this.field_6207 = new class_1331(this, 10, true);
        this.method_5875(true);
        this.field_5960 = true;
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1379(this, 1.0D, 40));
        this.field_6201.method_6277(1, new class_1361(this, class_1657.class, 8.0F));
        this.field_6201.method_6277(2, new class_1376(this));
        this.field_6201.method_6277(3, new FollowPlayerGoal(this, 1.3D, 8.0F, 2.0F));
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6354(true);
        nav.method_6331(true);
        return nav;
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0D)
                .method_26868(class_5134.field_23720, 0.6D)
                .method_26868(class_5134.field_23719, 0.3D)
                .method_26868(class_5134.field_23717, 32.0D);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!this.method_37908().field_9236) {
            this.method_5646();
        }

        if (this.field_5974.method_43057() < 0.02F) {
            this.method_18799(this.method_18798().method_1031(
                    (this.field_5974.method_43058() - 0.5D) * 0.05D,
                    (this.field_5974.method_43058() - 0.5D) * 0.05D,
                    (this.field_5974.method_43058() - 0.5D) * 0.05D
            ));
        }

        if (this.method_37908().method_8608()) {
            setupAnimationStates();
        }

        if (!this.method_37908().field_9236) {
            lifetime++;
            if (lifetime > MAX_LIFETIME) {
                this.method_31472();
            }
        }
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false;
    }

    @Override
    protected void method_5623(double heightDifference, boolean onGround, class_2680 landedState, class_2338 landedPosition) {
        // no fall damage for ghost
    }

    @Override
    public boolean method_5740() {
        return true;
    }

    @Override
    public boolean method_5679(class_1282 source) {
        if (source.method_48789(class_8103.field_42249)
                || source.method_48789(class_8103.field_42247)
                || source.method_48789(class_8103.field_42246)
                || source.method_48789(class_8103.field_42250)
                || source.method_48789(class_8103.field_42241)
                || source.method_48789(class_8103.field_42253)) {
            return true;
        }
        return super.method_5679(source);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 other) {
        return (class_1296) ModEntities.GHOST.method_5883(world);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(ModItems.OBINGOT);
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 110;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }
    }

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return class_3417.field_14566;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15054;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14648;
    }
}
